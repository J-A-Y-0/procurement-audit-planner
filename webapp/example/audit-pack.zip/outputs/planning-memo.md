# Procurement audit: planning memo

*Prepared 2026-10-15. Scope approved by Jay Yu dated 2026-10-15 (register revision 1). See [review and sign-off](review.md).*

**Indicators, not findings.** Every test below checks a control against a pattern in public data. Nothing here asserts wrongdoing by the council, a department, an officer or a supplier.

## Purpose

Test whether recurring general procurement payments, spend after notice expiry and placement records show the controls the Rules require, using indicator language only.
The plan makes no finding of non-compliance; every flagged pattern is a screen to be checked against records.

## Background

The planning population is 8,534 retained published payment rows above the expenditure publication level across 3 months [metric:$.population.rows_after_exclusions]; these are not all payments above the contract-publication boundary.
All five approved risks are in scope and are carried from the register and the auditor decisions.
Provenance: only rule and history extraction is cached; analytics and risk ratings were generated anew for this run.
The fixed competition bands in CPR-61 are sourced and are tested in C-01.1 against the actual requirement total; bands that depend on unsourced Threshold parameters are not applied and are recorded as limitations [rule:CPR-61].

## Scope

The register lists 5 rated risks. The auditor recorded 5 decisions by Jay Yu dated 2026-10-15: 5 risks are approved and in scope, and 0 are not.

| ID | Risk | Score | Band | Decision | Auditor comment |
|---|---|---|---|---|---|
| R-01 | Aggregation of repeated general procurement payments to one supplier | 9 | Medium - High | approve |  |
| R-02 | Competition and register evidence for general procurement suppliers | 6 | Moderate | approve | Scope approved with a factual correction: 674 is the total eligible supplier population, not the number without an exact match. Match-class counts are 40 exact, 5 near containment, 2 near string matches and 627 with no match. The general procurement no-match count of 190 is correct. Use the appropriate denominator and retain the notice-coverage limitation. |
| R-03 | Repeated equal-value payments in payment runs | 6 | Moderate | approve | Scope approved. CPR-40 requires payment within 30 days of a valid, undisputed invoice; it does not itself prohibit duplicate payments. Treat repeated equal-value payments as an analytical indicator, verify invoices and receipts, and include a separate invoice-timeliness procedure when relying on CPR-40. No duplicate loss or breach is established by the payment data. |
| R-04 | Recorded reasons for care and education provider choice | 6 | Moderate | approve |  |
| R-05 | Spend after notice expiry and value above awarded contract rates | 9 | Medium - High | approve |  |

## Approach

Each approved risk maps to one expected control, a test with an objective pass or fail procedure, a deterministic sample recipe and PBC requests.
The builder draws every sample from the full analytics lists and verifies each item against the cleaned spend data; the planner does not select transactions.
Sample sizes follow risk scores, with the larger samples for the higher-scored risks.
Each test establishes applicability and source coverage before testing compliance; a screen is never itself a failure.
The notice match is a visibility check: a published notice or award record supports the contract register entry and formal award notification required by the Rules but does not replace them [rule:CPR-05] [rule:CPR-30].

The programme holds 5 expected controls and 6 test steps, with 234 sampled transactions worth £11,795,010.95, each traceable to its row in the council's published workbooks (see `audit-program.md` and `outputs/samples/`).

## Rules coverage

11 of 74 rules in `rules.json` are cited by a risk, a control or a test. The remaining 63 are not tested in this audit, for these reasons:

- budget provision evidence is not in the inputs: CPR-01
- award approval and delegation records are not in the inputs; award value bands alone do not show who approved an award: CPR-02, CPR-57, CPR-58, CPR-59, CPR-60
- publication and reporting duties are met by published records outside the spend file and are not testable from payment data alone: CPR-03, CPR-04, CPR-06
- tender process, advertising and submission records are not in the inputs: CPR-07, CPR-08, CPR-09, CPR-11, CPR-12, CPR-13, CPR-14, CPR-15, CPR-16
- competition route bands at the unsourced Threshold tiers depend on parameters not supplied; the sourced fixed bands are covered by C-01.1 and tender records are not in the inputs: CPR-63, CPR-64, CPR-65
- exception and waiver records are not in the inputs; each rule depends on exception documents: CPR-17, CPR-18, CPR-19, CPR-20, CPR-21, CPR-22, CPR-23, CPR-24, CPR-67, CPR-68, CPR-69
- contract documentation, reports and sealing records are not in the inputs: CPR-25, CPR-26, CPR-27, CPR-28, CPR-29, CPR-31, CPR-42, CPR-50, CPR-51, CPR-52, CPR-53, CPR-54, CPR-55, CPR-56
- contract clause content is held in documents outside the spend data: CPR-32, CPR-33, CPR-34, CPR-35, CPR-36, CPR-37, CPR-38, CPR-39
- insurance, bond and indemnity records are not in the inputs: CPR-43, CPR-44, CPR-45, CPR-46, CPR-47, CPR-48, CPR-49
- subcontract flow-down evidence is not in the inputs: CPR-41
- the preference prohibition is a conduct statement with no payment-level pattern to test: CPR-66

## Limitations

- The population excludes redacted supplier rows and inter-authority and statutory pension payments.
- Payment-run timestamps are not invoice dates, so invoice validity cannot be read from the spend data.
- No contract register is present; public notices are incomplete and an absent notice is an indicator to check.
- The clause on total contract value conflicts with the Appendix B wording on VAT; the conflict is not resolved here [rule:CPR-61].
- Ranked case lists are shortened in the projection; the full lists remain in the stored analytics and the builder uses them.

## Review and sign-off

The challenger's points and their status are in `challenges.md`; points marked *for the auditor* need a decision at sign-off. The QA reviewer's checks and verdict are in `review.md`, which ends with the sign-off block.
