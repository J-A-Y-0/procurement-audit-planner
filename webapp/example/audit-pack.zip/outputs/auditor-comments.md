# Auditor scope decisions

Reviewer: Jay Yu
Date: 2026-10-15

A blank Decision cell means no decision. Use approve, amend or reject. Rejection requires a reason. For an amendment, record exact field changes as JSON in Comment, for example {"recommend_in_scope": false}; a score change must also include its cited justification. The assistant may transcribe your explicit instructions, and may never authorise a decision.

| ID | Risk | Current rating | Scope | Decision | Comment |
|---|---|---|---|---|---|
| R-01 | Aggregation of repeated general procurement payments to one supplier | 9 / Medium - High | In | approve |  |
| R-02 | Competition and register evidence for general procurement suppliers | 6 / Moderate | In | approve | Scope approved with a factual correction: 674 is the total eligible supplier population, not the number without an exact match. Match-class counts are 40 exact, 5 near containment, 2 near string matches and 627 with no match. The general procurement no-match count of 190 is correct. Use the appropriate denominator and retain the notice-coverage limitation. |
| R-03 | Repeated equal-value payments in payment runs | 6 / Moderate | In | approve | Scope approved. CPR-40 requires payment within 30 days of a valid, undisputed invoice; it does not itself prohibit duplicate payments. Treat repeated equal-value payments as an analytical indicator, verify invoices and receipts, and include a separate invoice-timeliness procedure when relying on CPR-40. No duplicate loss or breach is established by the payment data. |
| R-04 | Recorded reasons for care and education provider choice | 6 / Moderate | In | approve |  |
| R-05 | Spend after notice expiry and value above awarded contract rates | 9 / Medium - High | In | approve |  |
