# Procurement audit risk register

*Revision 1, following auditor comments: approved risks unchanged.*

Status: risk assessment and auditor scope decisions; indicators are not findings of non-compliance.

Method: the council's likelihood and impact scales, Figure 1 matrix (risk-management-strategy-2024-27.pdf, PDF p.18) and Table 4 response bands (PDF p.19). Python computes likelihood × impact and looks up both printed labels.

Source discrepancies retained: Table 1 / Figure 1 use Medium impact at three although the introductory prose prints two; Figure 1 calls the middle upper band High while Table 4 calls it Medium–High. Table 4 controls the response band. Figure 4 separately places scores of nine or above on the Corporate Risk Register, while the adjacent prose and Table 4 describe escalation of Extreme risks. That different Figure 4 rule is disclosed, not silently substituted.

The financial percentage bands overlap in the source. No inferred budget, loss estimate or probability is calculated from payment totals. Impact is an explicit consequence scenario using the printed descriptors; likelihood is a consistent planning judgment under the skill rubric, not a measured event probability.

## Summary

| ID | Risk | L | I | Score | Matrix label | Response band | Proposed focus | Scope |
|---|---|---:|---:|---:|---|---|---|---|
| R-01 | Aggregation of repeated general procurement payments to one supplier | 3 | 3 | 9 | High | Medium - High | Obtain requirement and contract evidence for the flagged windows and test whether aggregated total value was routed correctly under the competition rules [rule:CPR-62]. | In |
| R-02 | Competition and register evidence for general procurement suppliers | 2 | 3 | 6 | Moderate | Moderate | Compare flagged suppliers with the council contract register and the award record for each relevant contract [rule:CPR-30]. | In |
| R-03 | Repeated equal-value payments in payment runs | 3 | 2 | 6 | Moderate | Moderate | Sample flagged groups against invoices, purchase orders and receipts to establish whether any payment was duplicated [rule:CPR-40]. | In |
| R-04 | Recorded reasons for care and education provider choice | 2 | 3 | 6 | Moderate | Moderate | Test a sample of placement case files for a recorded reason for the provider choice and for the approval route applied [rule:CPR-73]. | In |
| R-05 | Spend after notice expiry and value above awarded contract rates | 3 | 3 | 9 | High | Medium - High | Confirm for each flagged supplier whether an extension or variation was approved under the extension and variation rules [rule:CPR-71] [rule:CPR-72]. | In |

## R-01: Aggregation of repeated general procurement payments to one supplier

Recurring payments to the same supplier within short windows may mean one requirement was procured in parts, so the aggregated value and the required route were not tested as a whole. The prohibited behaviour is artificial disaggregation; the required control is aggregation of total contract value [rule:CPR-10].

Likelihood (3): A nonzero eligible general procurement window pattern exists [metric:$.tests.split_purchases.25000.headline_general_procurement.windows]. Periodic payments under one requirement are an alternative explanation that cannot be excluded without requirement and contract evidence [rule:CPR-10].

Impact (3): Scenario: a competition route not applied to aggregated value, a compliance consequence [history:$.scoring_method.impact_scale[2]] with contract-related exposure [history:RT-02]. The gross payment figure is an exposure indicator, not a measured loss [metric:$.tests.split_purchases.25000.headline_general_procurement.gbp].

Evidence:
- General procurement windows at the upper screening level: 44 [metric:$.tests.split_purchases.25000.headline_general_procurement.windows].
- General procurement windows at the lower screening level: 80 [metric:$.tests.split_purchases.1000.headline_general_procurement.windows].

Proposed focus: Obtain requirement and contract evidence for the flagged windows and test whether aggregated total value was routed correctly under the competition rules [rule:CPR-62].
Sample source: `split_purchases_windows.csv`

## R-02: Competition and register evidence for general procurement suppliers

Suppliers at or above the publication level with no matching published notice may have been engaged without a visible competition record. No contract register is present, so this is a visibility gap and not evidence of off-contract spend [rule:CPR-05].

Likelihood (2): Rule and visibility gap only: the register is absent and notice coverage is limited, so an unmatched supplier is an indicator to check [metric:$.tests.off_contract.unmatched_by_tag[2].count] [rule:CPR-62].

Impact (3): Scenario: unrecorded competition on a contract, a compliance consequence [history:$.scoring_method.impact_scale[2]] with contractual exposure [history:RT-02]. The annualised figure is a screening indicator [metric:$.tests.off_contract.counts_by_match_class[3].gbp_annualised].

Evidence:
- General procurement suppliers with no matching notice: 190 [metric:$.tests.off_contract.unmatched_by_tag[2].count].
- Eligible suppliers not exactly matched: 674 [metric:$.tests.off_contract.eligible_supplier_count].

Proposed focus: Compare flagged suppliers with the council contract register and the award record for each relevant contract [rule:CPR-30].
Sample source: `supplier-match.csv`

## R-03: Repeated equal-value payments in payment runs

Equal-value payments to one supplier within a short span may indicate a duplicate or unnecessary payment. Payment-run timestamps are not invoice dates, and recurring placements may explain the pattern [rule:CPR-40].

Likelihood (3): Different-date equal-value groups are a nonzero eligible indicator [metric:$.tests.duplicates.different_time.groups]. Same-timestamp groups alone would support only base two [metric:$.tests.duplicates.same_timestamp.groups]. No invoice dates are available to resolve the pattern.

Impact (2): Minor financial scenario [history:$.scoring_method.impact_scale[1]]. The gross figure is an exposure indicator, not recoverable loss [metric:$.tests.duplicates.different_time.gbp_beyond_first_instance]. The Accounts Payable audit [history:AUD-15] gave Reasonable Assurance, which is not an adverse prior opinion and does not raise the score.

Evidence:
- Equal-value groups with different payment dates: 280 [metric:$.tests.duplicates.different_time.groups].
- Equal-value groups within one payment run: 433 [metric:$.tests.duplicates.same_timestamp.groups].

Proposed focus: Sample flagged groups against invoices, purchase orders and receipts to establish whether any payment was duplicated [rule:CPR-40].
Sample source: document/enquiry test; no transaction sample assumed.

## R-04: Recorded reasons for care and education provider choice

Placements in the care and education tag may lack the case-note record of the reason for provider choice that the exemption conditions require. The payment data cannot see case notes, so this is a document-test gap [rule:CPR-73].

Likelihood (2): Visibility gap only: case notes are not in the data and the tag is a screening proxy for exemption use [metric:$.population.tags.care_or_education_placement.rows] [rule:CPR-73]. A different care audit [history:AUD-18] does not establish a repeat finding on this control.

Impact (3): Scenario: an exemption applied without recorded reasons, a compliance consequence [history:$.scoring_method.impact_scale[2]] with possible regulatory interest [history:RT-02].

Evidence:
- Placement tag rows: 5,839 [metric:$.population.tags.care_or_education_placement.rows].
- High value placement suppliers: 353 [metric:$.tests.high_value_suppliers.care_or_education_placement.count].

Proposed focus: Test a sample of placement case files for a recorded reason for the provider choice and for the approval route applied [rule:CPR-73].
Sample source: document/enquiry test; no transaction sample assumed.

## R-05: Spend after notice expiry and value above awarded contract rates

Payments to suppliers after a published notice end date, and run-rates well above awarded values, may indicate extensions or variations not approved under the extension rules. Public notices are incomplete, so this is an indicator to check against the register [rule:CPR-70].

Likelihood (3): Nonzero screening indicators exist for expired notices and for variation ratios [metric:$.tests.expired_notice_spend.count] [metric:$.tests.spend_vs_award.count]. An undisclosed newer contract is an alternative explanation that remains open [rule:CPR-70].

Impact (3): Scenario: an extension or variation without the required approval, a compliance consequence [history:$.scoring_method.impact_scale[2]] with contractual exposure [history:RT-02]. Whole-term award values are not losses and the run-rate is an estimate [metric:$.tests.spend_vs_award.count].

Evidence:
- Expired notice indicators: 7 [metric:$.tests.expired_notice_spend.count].
- Spend against award indicators: 8 [metric:$.tests.spend_vs_award.count].

Proposed focus: Confirm for each flagged supplier whether an extension or variation was approved under the extension and variation rules [rule:CPR-71] [rule:CPR-72].
Sample source: document/enquiry test; no transaction sample assumed.

## Excluded themes

- Grants and other groups: Grant rows are retained and separately tagged, but no purchase-control breach can be inferred from the narrative alone [rule:CPR-61].
- Off-contract test for suppliers below the publication level: Not classified by the test, and contract notice data does not cover smaller awards [metric:$.tests.off_contract.below_publication_threshold_not_classified].

## Source references

- [history:$.scoring_method.impact_scale[1]] risk-management-strategy-2024-27.pdf, PDF p.14: “0.01% 0.1% of annual WBC budget £17.5k £175k”
- [history:$.scoring_method.impact_scale[2]] risk-management-strategy-2024-27.pdf, PDF p.14: “0.1% - 0.3% annual WBC budget £175k -500k”
- [history:AUD-15] audit-completed-work-2025-26-q3.pdf, PDF p.1: “Accounts Payable Reasonable Assurance”
- [history:AUD-18] audit-completed-work-2025-26-q3.pdf, PDF p.1: “Purchase of Residential and Nursing Care Provision Reasonable Assurance”
- [history:RT-02] risk-management-strategy-2024-27.pdf, PDF p.14: “Compliance (litigation, regulatory, contract)”
- [metric:$.population.tags.care_or_education_placement.rows] analytics.json: 5,839
- [metric:$.tests.duplicates.different_time.gbp_beyond_first_instance] analytics.json: 3,254,020.77
- [metric:$.tests.duplicates.different_time.groups] analytics.json: 280
- [metric:$.tests.duplicates.same_timestamp.groups] analytics.json: 433
- [metric:$.tests.expired_notice_spend.count] analytics.json: 7
- [metric:$.tests.high_value_suppliers.care_or_education_placement.count] analytics.json: 353
- [metric:$.tests.off_contract.counts_by_match_class[3].gbp_annualised] analytics.json: 249,872,150.36
- [metric:$.tests.off_contract.eligible_supplier_count] analytics.json: 674
- [metric:$.tests.off_contract.unmatched_by_tag[2].count] analytics.json: 190
- [metric:$.tests.spend_vs_award.count] analytics.json: 8
- [metric:$.tests.split_purchases.1000.headline_general_procurement.windows] analytics.json: 80
- [metric:$.tests.split_purchases.25000.headline_general_procurement.gbp] analytics.json: 2,460,912.62
- [metric:$.tests.split_purchases.25000.headline_general_procurement.windows] analytics.json: 44
- [rule:CPR-05] clause 5.2.1, PDF p.3: “A register of contracts, including those in progress and those awarded, with key information such as the contract value, duration and supplier.”
- [rule:CPR-10] clause 6.16, PDF p.5: “There shall be no artificial splitting or disaggregation of a contract to avoid the application of the provisions of the Procurement Legislation and/or these Rules.”
- [rule:CPR-30] clause 10.4, PDF p.8: “The relevant Service Director must formally notify the Service Lead for Commissioning and Procurement (or nominated officer) of the award of all contracts for the purpose of it being recorded on the Council Contract Register.”
- [rule:CPR-40] clause 10.7.9.1, PDF p.8: “any payment due from the Council is made no later than 30 days from the date on which the relevant invoice is regarded as valid and undisputed; and”
- [rule:CPR-62] clause App B row B1, PDF p.12: “Invitations to quote must be sent via the Procurement Portal to at least three appropriate sources, including at least one SME* or VCSE* organisation and one local supplier ****(where appropriate and possible**).”
- [rule:CPR-70] clause App C row D, PDF p.14: “Approval of the S151 Officer”
- [rule:CPR-71] clause App C row E (below Threshold), PDF p.14: “For contract value below the Threshold prior written approval from the Monitoring Officer and S151 Officer is required.”
- [rule:CPR-72] clause App C row E (above Threshold), PDF p.14: “For contract value greater than the Threshold, approval of the relevant board, following the submission of an extension report to the relevant board with recommendation from Monitoring Officer and S151 Officer”
- [rule:CPR-73] clause App C row F, PDF p.15: “Service Directors must ensure that a record of the reasons for the choice of provider is maintained on the individual’s case notes.”

## Auditor decisions

- R-01: approve; approved without amendment. Applied in this revision.
- R-02: approve; Scope approved with a factual correction: 674 is the total eligible supplier population, not the number without an exact match. Match-class counts are 40 exact, 5 near containment, 2 near string matches and 627 with no match. The general procurement no-match count of 190 is correct. Use the appropriate denominator and retain the notice-coverage limitation.. Applied in this revision.
- R-03: approve; Scope approved. CPR-40 requires payment within 30 days of a valid, undisputed invoice; it does not itself prohibit duplicate payments. Treat repeated equal-value payments as an analytical indicator, verify invoices and receipts, and include a separate invoice-timeliness procedure when relying on CPR-40. No duplicate loss or breach is established by the payment data.. Applied in this revision.
- R-04: approve; approved without amendment. Applied in this revision.
- R-05: approve; approved without amendment. Applied in this revision.
