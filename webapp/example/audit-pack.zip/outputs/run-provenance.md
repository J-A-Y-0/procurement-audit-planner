# Run provenance

Live AI run: risk assessment, planning, challenge and QA interpretation are generated for this run. The fixed dataset uses Part A’s verified rule and audit-history extraction cache; source quotations are verified again. Payment calculations, scores, samples and validation are computed by Python. Human decisions are separate and never supplied by the model.
