# Risk-control matrix

*Prepared 2026-10-15. Scope approved by Jay Yu dated 2026-10-15 (register revision 1). See [review and sign-off](review.md).*

**Indicators, not findings.** Every test below checks a control against a pattern in public data. Nothing here asserts wrongdoing by the council, a department, an officer or a supplier.

| Risk | Score | Expected control | Rules | Tests |
|---|---|---|---|---|
| R-01: Aggregation of repeated general procurement payments to one supplier | 9 (Medium - High) | C-01.1: General procurement requirements are aggregated to total contract value and routed under the applicable competition band. | CPR-10, CPR-61, CPR-62 | T-01.1 |
| R-02: Competition and register evidence for general procurement suppliers | 6 (Moderate) | C-02.1: General procurement suppliers above the publication level have a contract register entry and a formal award notification recorded. | CPR-05, CPR-30 | T-02.1 |
| R-03: Repeated equal-value payments in payment runs | 6 (Moderate) | C-03.1: Each payment is made once against a valid, undisputed invoice and settled within the contractual payment deadline. | CPR-40 | T-03.1 |
| R-04: Recorded reasons for care and education provider choice | 6 (Moderate) | C-04.1: Placements made under an exemption record the reason for provider choice in case notes. | CPR-73, CPR-74 | T-04.1 |
| R-05: Spend after notice expiry and value above awarded contract rates | 9 (Medium - High) | C-05.1: Payments after notice expiry or above awarded values are covered by approved extensions or variations. | CPR-70, CPR-71, CPR-72 | T-05.1, T-05.2 |
