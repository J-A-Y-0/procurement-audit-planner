# Audit program

*Prepared 2026-10-15. Scope approved by Jay Yu dated 2026-10-15 (register revision 1). See [review and sign-off](review.md).*

**Indicators, not findings.** Every test below checks a control against a pattern in public data. Nothing here asserts wrongdoing by the council, a department, an officer or a supplier.

5 risks in scope, 5 controls, 6 tests, 234 sampled transactions. Samples are drawn by the builder from `analytics-full/` by the recipe stated under each test, and every transaction is listed with its workbook row.


## R-01: Aggregation of repeated general procurement payments to one supplier [9 (High; Medium - High)]

**Audit objective.** Establish whether recurring general procurement payments to one supplier within short windows reflect one requirement that was aggregated and routed correctly, or a split that avoided the applicable route.

**C-01.1. Expected control.** General procurement requirements are aggregated to total contract value and routed under the applicable competition band. [CPR-10, CPR-61, CPR-62]

**T-01.1. Test.** Obtain requirement, order and contract records for each sampled window at the fixed band in the sample recipe. Verify the actual requirement and contract total, including any VAT treatment documented, and compare that total with the applicable fixed competition band under CPR-61 and CPR-62. Pass where records show aggregation and a route consistent with the applicable band; fail where the aggregated total fell in a competition band, no route was applied and no record explains the split. Windows at the lower fixed band are excluded from this sample by design and form a separate follow-up population to be tested before any conclusion on that band. Where the VAT basis or applicability is unresolved, record follow-up rather than a breach. [CPR-10, CPR-61, CPR-62, metric:$.tests.split_purchases.25000.headline_general_procurement.windows]  
**Evidence to inspect:** Purchase orders, quotations, aggregation note, VAT basis record and route decision for each window  
**Sample:** 10 items from `split_purchases_windows.csv`, where dominant_tag = general_procurement, threshold_value = 25000, largest window_total first; 180 transactions

| # | Row ID | Date | Supplier | Amount | Service |
|---|---|---|---|---|---|
| 1 | `Over500_2026_P02_-_published.xlsx:2181` | 2026-05-05 | VolkerHighways Ltd | £9,068.36 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:2178` | 2026-05-05 | VolkerHighways Ltd | £16,916.01 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:695` | 2026-05-05 | VolkerHighways Ltd | £15,041.26 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:2177` | 2026-05-05 | VolkerHighways Ltd | £16,876.43 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:2174` | 2026-05-05 | VolkerHighways Ltd | £4,764.64 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:723` | 2026-05-05 | VolkerHighways Ltd | £18,033.36 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:713` | 2026-05-05 | VolkerHighways Ltd | £7,742.55 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:727` | 2026-05-11 | VolkerHighways Ltd | £3,196.62 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:714` | 2026-05-12 | VolkerHighways Ltd | £1,550.00 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:724` | 2026-05-12 | VolkerHighways Ltd | £7,828.20 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:701` | 2026-05-12 | VolkerHighways Ltd | £17,896.87 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:696` | 2026-05-12 | VolkerHighways Ltd | £2,566.36 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:703` | 2026-05-13 | VolkerHighways Ltd | £12,297.34 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:2179` | 2026-05-19 | VolkerHighways Ltd | £17,882.35 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:2193` | 2026-05-19 | VolkerHighways Ltd | £1,668.58 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:731` | 2026-05-20 | VolkerHighways Ltd | £2,585.44 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:2185` | 2026-05-20 | VolkerHighways Ltd | £19,420.72 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:728` | 2026-05-20 | VolkerHighways Ltd | £10,169.81 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:2170` | 2026-05-20 | VolkerHighways Ltd | £16,304.62 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:2172` | 2026-05-22 | VolkerHighways Ltd | £2,070.26 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:730` | 2026-05-22 | VolkerHighways Ltd | £1,679.16 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:734` | 2026-05-22 | VolkerHighways Ltd | £5,199.81 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:2182` | 2026-05-26 | VolkerHighways Ltd | £4,046.54 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:726` | 2026-05-26 | VolkerHighways Ltd | £2,610.11 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:697` | 2026-05-26 | VolkerHighways Ltd | £1,711.48 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:2180` | 2026-05-26 | VolkerHighways Ltd | £7,015.34 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:721` | 2026-05-26 | VolkerHighways Ltd | £10,122.39 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:716` | 2026-05-26 | VolkerHighways Ltd | £850.00 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:715` | 2026-05-26 | VolkerHighways Ltd | £5,225.72 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:693` | 2026-05-27 | VolkerHighways Ltd | £5,997.50 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:699` | 2026-05-27 | VolkerHighways Ltd | £1,793.45 | Environment |
| 1 | `Over500_2026_P02_-_published.xlsx:694` | 2026-05-27 | VolkerHighways Ltd | £8,175.00 | Environment |
| 2 | `Over500_2026_P02_-_published.xlsx:9` | 2026-05-28 | The Better Group Ltd | £20,457.43 | Adult Social Care |
| 2 | `Over500_2026_P02_-_published.xlsx:10` | 2026-05-28 | The Better Group Ltd | £19,605.14 | Children's Social Care |
| 2 | `Over500_2026_P02_-_published.xlsx:11` | 2026-05-28 | The Better Group Ltd | £2,557.08 | Education & SEND |
| 2 | `Over500_2026_P03_-_published.xlsx:13` | 2026-06-01 | The Better Group Ltd | £24,088.98 | Children's Social Care |
| 2 | `Over500_2026_P03_-_published.xlsx:2397` | 2026-06-01 | The Better Group Ltd | £22,361.26 | Adult Social Care |
| 2 | `Over500_2026_P03_-_published.xlsx:16` | 2026-06-01 | The Better Group Ltd | £15,478.22 | Children's Social Care |
| 2 | `Over500_2026_P03_-_published.xlsx:19` | 2026-06-01 | The Better Group Ltd | £3,142.04 | Education & SEND |
| 2 | `Over500_2026_P03_-_published.xlsx:20` | 2026-06-01 | The Better Group Ltd | £2,018.90 | Education & SEND |
| 2 | `Over500_2026_P03_-_published.xlsx:26` | 2026-06-01 | The Better Group Ltd | £16,151.18 | Adult Social Care |
| 2 | `Over500_2026_P03_-_published.xlsx:2396` | 2026-06-01 | The Better Group Ltd | £18,039.18 | Adult Social Care |
| 2 | `Over500_2026_P03_-_published.xlsx:379` | 2026-06-09 | The Better Group Ltd | £14,706.64 | Adult Social Care - Transformation Projects |
| 2 | `Over500_2026_P03_-_published.xlsx:394` | 2026-06-09 | The Better Group Ltd | £12,427.19 | Adult Social Care - Transformation Projects |
| 2 | `Over500_2026_P03_-_published.xlsx:395` | 2026-06-09 | The Better Group Ltd | £11,180.63 | Adult Social Care - Transformation Projects |
| 2 | `Over500_2026_P03_-_published.xlsx:27` | 2026-06-25 | The Better Group Ltd | £2,557.48 | Children's Social Care |
| 2 | `Over500_2026_P03_-_published.xlsx:15` | 2026-06-25 | The Better Group Ltd | £2,668.67 | Adult Social Care |
| 3 | `Over500_2026_P03_-_published.xlsx:357` | 2026-06-01 | Newbury & District Ltd | £6,349.35 | Environment |
| 3 | `Over500_2026_P03_-_published.xlsx:268` | 2026-06-01 | Newbury & District Ltd | £13,826.61 | Environment |
| 3 | `Over500_2026_P03_-_published.xlsx:171` | 2026-06-02 | Newbury & District Ltd | £10,529.33 | Education & SEND |
| 3 | `Over500_2026_P03_-_published.xlsx:341` | 2026-06-02 | Newbury & District Ltd | £794.67 | Education & SEND |
| 3 | `Over500_2026_P03_-_published.xlsx:336` | 2026-06-02 | Newbury & District Ltd | £9,861.00 | Education & SEND |
| 3 | `Over500_2026_P03_-_published.xlsx:264` | 2026-06-12 | Newbury & District Ltd | £6,331.70 | Environment |
| 3 | `Over500_2026_P03_-_published.xlsx:269` | 2026-06-12 | Newbury & District Ltd | £14,852.00 | Environment |
| 3 | `Over500_2026_P03_-_published.xlsx:360` | 2026-06-30 | Newbury & District Ltd | £4,465.96 | Environment |
| 3 | `Over500_2026_P03_-_published.xlsx:359` | 2026-06-30 | Newbury & District Ltd | £5,921.50 | Environment |
| 3 | `Over500_2026_P03_-_published.xlsx:274` | 2026-06-30 | Newbury & District Ltd | £13,663.85 | Environment |
| 3 | `Over500_2026_P03_-_published.xlsx:251` | 2026-06-30 | Newbury & District Ltd | £627.37 | Education & SEND |
| 3 | `Over500_2026_P03_-_published.xlsx:213` | 2026-06-30 | Newbury & District Ltd | £8,312.63 | Education & SEND |
| 3 | `Over500_2026_P03_-_published.xlsx:176` | 2026-06-30 | Newbury & District Ltd | £7,785.00 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:302` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £7,911.27 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:301` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £1,039.14 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:300` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £999.32 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:253` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £2,118.96 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:450` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £9,615.23 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:451` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £574.66 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:246` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £4,549.40 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:309` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £2,974.60 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:452` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £9,483.38 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:196` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £862.12 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:195` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £730.27 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:459` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £2,312.52 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:183` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £8,226.54 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:181` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £1,197.90 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:245` | 2026-07-08 | WEAVAWAY TRAVEL LTD | £1,214.56 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:311` | 2026-07-24 | WEAVAWAY TRAVEL LTD | £1,947.39 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:456` | 2026-07-24 | WEAVAWAY TRAVEL LTD | £8,097.04 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:192` | 2026-07-24 | WEAVAWAY TRAVEL LTD | £6,662.12 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:305` | 2026-07-24 | WEAVAWAY TRAVEL LTD | £7,986.00 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:250` | 2026-07-24 | WEAVAWAY TRAVEL LTD | £3,831.07 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:249` | 2026-07-24 | WEAVAWAY TRAVEL LTD | £6,927.61 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:198` | 2026-07-24 | WEAVAWAY TRAVEL LTD | £2,504.93 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:197` | 2026-07-24 | WEAVAWAY TRAVEL LTD | £614.96 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:310` | 2026-07-24 | WEAVAWAY TRAVEL LTD | £1,784.39 | Education & SEND |
| 4 | `Over500_2026_P04_-_published.xlsx:460` | 2026-07-24 | WEAVAWAY TRAVEL LTD | £726.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:344` | 2026-05-06 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,744.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:345` | 2026-05-06 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,548.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:346` | 2026-05-06 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £1,500.80 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:347` | 2026-05-06 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,041.67 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:383` | 2026-05-12 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,210.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:265` | 2026-05-12 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,912.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:385` | 2026-05-12 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,324.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:384` | 2026-05-12 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,156.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:382` | 2026-05-12 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £1,596.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:381` | 2026-05-12 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,716.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:380` | 2026-05-12 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,448.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:390` | 2026-05-13 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,079.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:389` | 2026-05-13 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,744.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:388` | 2026-05-13 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,576.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:387` | 2026-05-13 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,590.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:241` | 2026-05-13 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £1,288.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:290` | 2026-05-13 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £1,288.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:289` | 2026-05-13 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £1,980.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:266` | 2026-05-13 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £1,092.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:242` | 2026-05-13 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £693.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:430` | 2026-05-28 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,187.50 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:429` | 2026-05-28 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £1,608.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:428` | 2026-05-28 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,745.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:427` | 2026-05-28 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,925.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:426` | 2026-05-28 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,227.50 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:425` | 2026-05-28 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,550.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:423` | 2026-05-28 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,622.86 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:294` | 2026-05-28 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,244.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:422` | 2026-05-28 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,910.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:251` | 2026-05-28 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £742.50 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:283` | 2026-05-28 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,340.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:284` | 2026-05-28 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £3,120.00 | Education & SEND |
| 5 | `Over500_2026_P02_-_published.xlsx:424` | 2026-05-28 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,940.00 | Education & SEND |
| 5 | `Over500_2026_P03_-_published.xlsx:333` | 2026-06-05 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £1,380.00 | Education & SEND |
| 5 | `Over500_2026_P03_-_published.xlsx:346` | 2026-06-05 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,310.00 | Education & SEND |
| 5 | `Over500_2026_P03_-_published.xlsx:255` | 2026-06-05 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £1,710.00 | Education & SEND |
| 5 | `Over500_2026_P03_-_published.xlsx:184` | 2026-06-05 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,490.00 | Education & SEND |
| 5 | `Over500_2026_P03_-_published.xlsx:228` | 2026-06-05 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,775.00 | Education & SEND |
| 5 | `Over500_2026_P03_-_published.xlsx:164` | 2026-06-05 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £1,380.00 | Education & SEND |
| 5 | `Over500_2026_P03_-_published.xlsx:229` | 2026-06-05 | FD TRAVELS LIMITED T/A SCHOOL EXPRESS | £2,760.00 | Education & SEND |
| 6 | `Over500_2026_P04_-_published.xlsx:598` | 2026-07-13 | Roadside Technologies Ltd | £5,594.11 | Environment |
| 6 | `Over500_2026_P04_-_published.xlsx:601` | 2026-07-13 | Roadside Technologies Ltd | £9,103.64 | Environment |
| 6 | `Over500_2026_P04_-_published.xlsx:733` | 2026-07-13 | Roadside Technologies Ltd | £11,188.22 | Environment |
| 6 | `Over500_2026_P04_-_published.xlsx:734` | 2026-07-13 | Roadside Technologies Ltd | £5,594.11 | Environment |
| 6 | `Over500_2026_P04_-_published.xlsx:735` | 2026-07-13 | Roadside Technologies Ltd | £21,000.00 | Environment |
| 6 | `Over500_2026_P04_-_published.xlsx:740` | 2026-07-13 | Roadside Technologies Ltd | £9,103.64 | Environment |
| 6 | `Over500_2026_P04_-_published.xlsx:789` | 2026-07-13 | Roadside Technologies Ltd | £5,594.11 | Environment |
| 6 | `Over500_2026_P04_-_published.xlsx:1287` | 2026-07-13 | Roadside Technologies Ltd | £10,298.22 | Environment |
| 6 | `Over500_2026_P04_-_published.xlsx:1288` | 2026-07-13 | Roadside Technologies Ltd | £5,594.11 | Environment |
| 6 | `Over500_2026_P04_-_published.xlsx:597` | 2026-07-30 | Roadside Technologies Ltd | £1,000.00 | Environment |
| 7 | `Over500_2026_P02_-_published.xlsx:530` | 2026-05-27 | Elior UK PLC | £23,694.03 | Adult Social Care |
| 7 | `Over500_2026_P03_-_published.xlsx:434` | 2026-06-11 | Elior UK PLC | £11,935.93 | Adult Social Care |
| 7 | `Over500_2026_P03_-_published.xlsx:440` | 2026-06-16 | Elior UK PLC | £23,516.69 | Adult Social Care |
| 7 | `Over500_2026_P03_-_published.xlsx:433` | 2026-06-17 | Elior UK PLC | £18,592.30 | Adult Social Care |
| 8 | `Over500_2026_P02_-_published.xlsx:240` | 2026-05-12 | BROADWAY CARS | £1,213.33 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:372` | 2026-05-12 | BROADWAY CARS | £3,640.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:371` | 2026-05-12 | BROADWAY CARS | £2,240.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:369` | 2026-05-12 | BROADWAY CARS | £3,640.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:368` | 2026-05-12 | BROADWAY CARS | £2,100.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:364` | 2026-05-12 | BROADWAY CARS | £3,747.69 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:367` | 2026-05-12 | BROADWAY CARS | £2,800.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:288` | 2026-05-12 | BROADWAY CARS | £2,426.67 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:314` | 2026-05-13 | BROADWAY CARS | £595.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:245` | 2026-05-13 | BROADWAY CARS | £2,076.67 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:391` | 2026-05-13 | BROADWAY CARS | £1,785.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:394` | 2026-05-13 | BROADWAY CARS | £3,220.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:395` | 2026-05-13 | BROADWAY CARS | £3,640.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:396` | 2026-05-13 | BROADWAY CARS | £3,010.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:297` | 2026-05-13 | BROADWAY CARS | £1,148.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:404` | 2026-05-26 | BROADWAY CARS | £4,015.38 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:403` | 2026-05-26 | BROADWAY CARS | £3,000.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:415` | 2026-05-27 | BROADWAY CARS | £1,785.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:414` | 2026-05-27 | BROADWAY CARS | £3,220.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:416` | 2026-05-27 | BROADWAY CARS | £3,900.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:418` | 2026-05-27 | BROADWAY CARS | £3,900.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:419` | 2026-05-27 | BROADWAY CARS | £3,010.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:412` | 2026-05-27 | BROADWAY CARS | £3,900.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:410` | 2026-05-27 | BROADWAY CARS | £2,400.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:326` | 2026-05-27 | BROADWAY CARS | £595.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:299` | 2026-05-27 | BROADWAY CARS | £1,230.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:292` | 2026-05-27 | BROADWAY CARS | £2,600.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:250` | 2026-05-27 | BROADWAY CARS | £2,225.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:249` | 2026-05-27 | BROADWAY CARS | £1,300.00 | Education & SEND |
| 8 | `Over500_2026_P02_-_published.xlsx:411` | 2026-05-27 | BROADWAY CARS | £2,250.00 | Education & SEND |
| 9 | `Over500_2026_P03_-_published.xlsx:688` | 2026-06-01 | R&A Haines Building Contractors | £20,332.89 | Development & Housing |
| 9 | `Over500_2026_P03_-_published.xlsx:733` | 2026-06-01 | R&A Haines Building Contractors | £9,666.85 | Development & Housing |
| 9 | `Over500_2026_P03_-_published.xlsx:709` | 2026-06-09 | R&A Haines Building Contractors | £5,487.25 | Development & Housing |
| 9 | `Over500_2026_P03_-_published.xlsx:740` | 2026-06-30 | R&A Haines Building Contractors | £16,600.00 | Development & Housing |
| 9 | `Over500_2026_P03_-_published.xlsx:742` | 2026-06-30 | R&A Haines Building Contractors | £18,707.55 | Development & Housing |
| 9 | `Over500_2026_P04_-_published.xlsx:628` | 2026-07-01 | R&A Haines Building Contractors | £666.28 | Development & Housing |
| 10 | `Over500_2026_P03_-_published.xlsx:641` | 2026-06-17 | Triple Value Impact | £13,275.00 | Chief Executive |
| 10 | `Over500_2026_P03_-_published.xlsx:642` | 2026-06-17 | Triple Value Impact | £6,612.00 | Chief Executive |
| 10 | `Over500_2026_P03_-_published.xlsx:2392` | 2026-06-17 | Triple Value Impact | £10,787.00 | Chief Executive |
| 10 | `Over500_2026_P03_-_published.xlsx:2393` | 2026-06-17 | Triple Value Impact | £13,110.00 | Chief Executive |
| 10 | `Over500_2026_P03_-_published.xlsx:649` | 2026-06-18 | Triple Value Impact | £24,244.00 | Chief Executive |


## R-02: Competition and register evidence for general procurement suppliers [6 (Moderate; Moderate)]

**Audit objective.** Establish whether general procurement suppliers at or above the publication level have a contract register entry and formal award notification, or a visible competition record.

**C-02.1. Expected control.** General procurement suppliers above the publication level have a contract register entry and a formal award notification recorded. [CPR-05, CPR-30] Owner: Service Lead for Commissioning and Procurement.

**T-02.1. Test.** For each sampled supplier, obtain the actual council contract register entry and the formal award notification required by CPR-05 and CPR-30, and compare them with the payments. Request the formal award notification evidence from the client. Published notices and award records are supporting evidence only and do not make either requirement pass. Pass where the register entry and formal award notification cover the supplier's payments; fail where either the register entry or the formal award notification is absent and no competition record is produced. A missing published notice alone is only an indicator, because public notices are incomplete. [CPR-05, CPR-30, metric:$.tests.off_contract.unmatched_by_tag[2].count]  
**Evidence to inspect:** Council contract register entry, formal award notification, and supporting notice references  
**Sample:** 5 items from `supplier-match.csv`, where dominant_tag = general_procurement, match_class = none, largest total_gbp first, 2 payments per supplier; 10 transactions

| # | Row ID | Date | Supplier | Amount | Service |
|---|---|---|---|---|---|
| 1 | `Over500_2026_P04_-_published.xlsx:793` | 2026-07-13 | VolkerHighways Ltd | £998,987.64 | Environment |
| 1 | `Over500_2026_P04_-_published.xlsx:603` | 2026-07-28 | VolkerHighways Ltd | £855,750.25 | Environment |
| 2 | `Over500_2026_P02_-_published.xlsx:2196` | 2026-05-27 | VEOLIA ES WEST BERKSHIRE LTD (CHAPS ONLY) | £2,201,856.40 | Environment |
| 2 | `Over500_2026_P03_-_published.xlsx:2146` | 2026-06-29 | VEOLIA ES WEST BERKSHIRE LTD (CHAPS ONLY) | £2,180,425.32 | Environment |
| 3 | `Over500_2026_P03_-_published.xlsx:2144` | 2026-06-25 | Millbrook Healthcare Limited | £1,141,918.00 | Finance, Property & Procurement |
| 3 | `Over500_2026_P03_-_published.xlsx:2216` | 2026-06-03 | Millbrook Healthcare Limited | £1,141,918.00 | Finance, Property & Procurement |
| 4 | `Over500_2026_P02_-_published.xlsx:665` | 2026-05-15 | The Better Group Ltd | £64,500.00 | Adult Social Care |
| 4 | `Over500_2026_P02_-_published.xlsx:666` | 2026-05-15 | The Better Group Ltd | £58,833.00 | Adult Social Care |
| 5 | `Over500_2026_P02_-_published.xlsx:473` | 2026-05-27 | SoftwareONE UK Ltd | £375,697.68 | Transformation, Customer & ICT |
| 5 | `Over500_2026_P02_-_published.xlsx:474` | 2026-05-27 | SoftwareONE UK Ltd | £85,871.04 | Transformation, Customer & ICT |


## R-03: Repeated equal-value payments in payment runs [6 (Moderate; Moderate)]

**Audit objective.** Establish whether repeated equal-value payments in payment runs were duplicate payments or recurring lawful payments, and whether invoices were paid within the contractual deadline.

**C-03.1. Expected control.** Each payment is made once against a valid, undisputed invoice and settled within the contractual payment deadline. [CPR-40]

**T-03.1. Test.** For each sampled group, obtain the invoices, purchase orders and receipts for each payment. Pass where each payment settles one valid invoice with a receipt; fail where a further payment has no supporting invoice. CPR-40 is the invoice-timeliness requirement, not a duplicate-payment prohibition; the timeliness comparison uses invoice validity and settlement dates against the contractual deadline and is performed only where those dates are obtained. Where they are not, record the timeliness check as a limitation rather than a result. [CPR-40, metric:$.tests.duplicates.different_time.groups]  
**Evidence to inspect:** Invoices, purchase orders, receipts, invoice validity dates and settlement dates  
**Sample:** 5 items from `duplicates.csv`, where tier = different_time, dominant_tag = general_procurement, largest gbp_beyond_first first; 12 transactions

| # | Row ID | Date | Supplier | Amount | Service |
|---|---|---|---|---|---|
| 1 | `Over500_2026_P04_-_published.xlsx:3308` | 2026-07-15 | VolkerHighways Ltd | £101,925.86 | Environment |
| 1 | `Over500_2026_P04_-_published.xlsx:618` | 2026-07-17 | VolkerHighways Ltd | £101,925.86 | Environment |
| 2 | `Over500_2026_P04_-_published.xlsx:3210` | 2026-07-13 | VolkerHighways Ltd | £54,241.36 | Environment |
| 2 | `Over500_2026_P04_-_published.xlsx:3302` | 2026-07-16 | VolkerHighways Ltd | £54,241.36 | Environment |
| 3 | `Over500_2026_P02_-_published.xlsx:2160` | 2026-05-12 | TWO SAINTS LTD | £27,147.69 | Development & Housing |
| 3 | `Over500_2026_P02_-_published.xlsx:2161` | 2026-05-13 | TWO SAINTS LTD | £27,147.69 | Development & Housing |
| 4 | `Over500_2026_P04_-_published.xlsx:3184` | 2026-07-13 | VolkerHighways Ltd | £17,882.35 | Environment |
| 4 | `Over500_2026_P04_-_published.xlsx:3185` | 2026-07-16 | VolkerHighways Ltd | £17,882.35 | Environment |
| 5 | `Over500_2026_P04_-_published.xlsx:598` | 2026-07-13 | Roadside Technologies Ltd | £5,594.11 | Environment |
| 5 | `Over500_2026_P04_-_published.xlsx:734` | 2026-07-13 | Roadside Technologies Ltd | £5,594.11 | Environment |
| 5 | `Over500_2026_P04_-_published.xlsx:789` | 2026-07-13 | Roadside Technologies Ltd | £5,594.11 | Environment |
| 5 | `Over500_2026_P04_-_published.xlsx:1288` | 2026-07-13 | Roadside Technologies Ltd | £5,594.11 | Environment |


## R-04: Recorded reasons for care and education provider choice [6 (Moderate; Moderate)]

**Audit objective.** Establish whether placements made under an exemption have a recorded reason for provider choice and the approval route applied.

**C-04.1. Expected control.** Placements made under an exemption record the reason for provider choice in case notes. [CPR-73, CPR-74] Owner: Service Directors.

**T-04.1. Test.** For each sampled placement supplier, identify from the placement approval records whether any sampled placement claims an exemption from the competition rules, and name the source of that claim. For each claimed exemption, obtain the individual case files and check for a recorded reason for the provider choice and the approval route applied. Pass where the reason is recorded in the case notes; fail where it is absent. Where no exemption is claimed, record that the placement is outside test scope rather than a breach. [CPR-73, CPR-74, metric:$.population.tags.care_or_education_placement.rows]  
**Evidence to inspect:** Case notes, placement approval records and exemption record  
**Sample:** 5 items from `high_value_suppliers_flagged.csv`, where dominant_tag = care_or_education_placement, largest total_gbp first, 2 payments per supplier; 10 transactions

| # | Row ID | Date | Supplier | Amount | Service |
|---|---|---|---|---|---|
| 1 | `Over500_2026_P04_-_published.xlsx:1850` | 2026-07-08 | BUPA Care Services | £10,400.00 | Adult Social Care |
| 1 | `Over500_2026_P04_-_published.xlsx:1039` | 2026-07-08 | BUPA Care Services | £9,903.62 | Adult Social Care |
| 2 | `Over500_2026_P04_-_published.xlsx:2320` | 2026-07-08 | Affinity Trust Support Ltd | £28,512.00 | Adult Social Care |
| 2 | `Over500_2026_P03_-_published.xlsx:1628` | 2026-06-24 | Affinity Trust Support Ltd | £26,394.66 | Adult Social Care |
| 3 | `Over500_2026_P03_-_published.xlsx:2171` | 2026-06-17 | Oaklands SEN School Berkshire Limited | £20,534.90 | Education (DSG Funded) & Other Education Grants |
| 3 | `Over500_2026_P03_-_published.xlsx:2172` | 2026-06-17 | Oaklands SEN School Berkshire Limited | £20,534.90 | Education (DSG Funded) & Other Education Grants |
| 4 | `Over500_2026_P02_-_published.xlsx:823` | 2026-05-13 | RUSKIN MILL TRUST | £179,236.76 | Adult Social Care |
| 4 | `Over500_2026_P02_-_published.xlsx:1822` | 2026-05-13 | RUSKIN MILL TRUST | £151,859.86 | Adult Social Care |
| 5 | `Over500_2026_P02_-_published.xlsx:2095` | 2026-05-26 | Amegreen Childrens Services | £36,705.55 | Children's Social Care |
| 5 | `Over500_2026_P04_-_published.xlsx:3080` | 2026-07-17 | Amegreen Childrens Services | £36,705.55 | Children's Social Care |


## R-05: Spend after notice expiry and value above awarded contract rates [9 (High; Medium - High)]

**Audit objective.** Establish whether payments after notice expiry or above awarded values were covered by approved extensions or variations.

**C-05.1. Expected control.** Payments after notice expiry or above awarded values are covered by approved extensions or variations. [CPR-70, CPR-71, CPR-72] Owner: S.151 Officer.

**T-05.1. Test.** For each sampled supplier, obtain the notice, any extension instrument and the approval record. Pass where the extension was approved under the extension provision before payments continued; fail where payments continued without approval. A newer contract not on the notices must be checked against the register before concluding. [CPR-70, metric:$.tests.expired_notice_spend.count]  
**Evidence to inspect:** Extension instruments, approval records and current contract register entry  
**Sample:** 7 items from `expired_notice_spend.csv`, largest annualised_estimate first, 2 payments per supplier, (only 7 available); 9 transactions

| # | Row ID | Date | Supplier | Amount | Service |
|---|---|---|---|---|---|
| 1 | `Over500_2026_P03_-_published.xlsx:704` | 2026-06-16 | Hope & Clay (Construction) Ltd | £91,306.75 | Environment |
| 2 | `Over500_2026_P03_-_published.xlsx:58` | 2026-06-03 | BERKSHIRE MECHANICAL SERVICES | £8,250.00 | Development & Housing |
| 2 | `Over500_2026_P03_-_published.xlsx:42` | 2026-06-03 | BERKSHIRE MECHANICAL SERVICES | £6,250.00 | Development & Housing |
| 3 | `Over500_2026_P02_-_published.xlsx:467` | 2026-05-08 | G7 BUSINESS SOLUTIONS LIMITED | £5,469.78 | Finance, Property & Procurement |
| 3 | `Over500_2026_P03_-_published.xlsx:531` | 2026-06-10 | G7 BUSINESS SOLUTIONS LIMITED | £5,469.78 | Finance, Property & Procurement |
| 4 | `Over500_2026_P02_-_published.xlsx:459` | 2026-05-15 | CACI Limited | £12,071.67 | Children's Social Care |
| 5 | `Over500_2026_P03_-_published.xlsx:686` | 2026-06-22 | Morton Pattison Ltd | £1,102.00 | Environment |
| 6 | `Over500_2026_P03_-_published.xlsx:821` | 2026-06-03 | Davis and Associates Consultancy Limited | £800.00 | Chief Executive |
| 7 | `Over500_2026_P04_-_published.xlsx:58` | 2026-07-20 | Tactical Facilities Management Ltd | £681.94 | Development & Housing |

**T-05.2. Test.** For each sampled supplier, obtain the award record and any variation approvals and compare the payments with the awarded value over the contract term. Pass where variations above the indicator ratio have approval under the variation rules; fail where payments exceed the awarded value without approval. The ratio is an indicator to confirm, not evidence of variation. [CPR-71, CPR-72, metric:$.tests.spend_vs_award.count]  
**Evidence to inspect:** Award value, variation approvals and board or officer approval records  
**Sample:** 8 items from `spend_vs_award.csv`, largest ratio first, 2 payments per supplier, excluding suppliers and rows already drawn in T-05.1, (only 8 available); 13 transactions

| # | Row ID | Date | Supplier | Amount | Service |
|---|---|---|---|---|---|
| 1 | `Over500_2026_P04_-_published.xlsx:905` | 2026-07-22 | NEC SOFTWARE SOLUTIONS UK LIMITED | £129,125.00 | Finance, Property & Procurement |
| 1 | `Over500_2026_P04_-_published.xlsx:492` | 2026-07-22 | NEC SOFTWARE SOLUTIONS UK LIMITED | £91,629.15 | Finance, Property & Procurement |
| 2 | `Over500_2026_P03_-_published.xlsx:396` | 2026-06-10 | BookingLab Limited | £24,000.00 | Transformation, Customer & ICT |
| 3 | `Over500_2026_P03_-_published.xlsx:384` | 2026-06-04 | Exacom Systems Ltd | £12,105.85 | Development & Housing |
| 4 | `Over500_2026_P04_-_published.xlsx:1276` | 2026-07-22 | WCL UK Ltd (Trading as Everything ICT) | £102,882.78 | Education & SEND |
| 5 | `Over500_2026_P03_-_published.xlsx:276` | 2026-06-30 | SMS-Environmental Ltd | £2,070.00 | Adult Social Care |
| 5 | `Over500_2026_P04_-_published.xlsx:365` | 2026-07-09 | SMS-Environmental Ltd | £1,335.60 | Adult Social Care |
| 6 | `Over500_2026_P02_-_published.xlsx:460` | 2026-05-20 | Softcat Ltd | £8,979.02 | Education & SEND |
| 6 | `Over500_2026_P03_-_published.xlsx:375` | 2026-06-17 | Softcat Ltd | £2,025.98 | Transformation, Customer & ICT |
| 7 | `Over500_2026_P03_-_published.xlsx:371` | 2026-06-08 | IDOX SOFTWARE LTD | £48,579.20 | Community Services |
| 7 | `Over500_2026_P02_-_published.xlsx:462` | 2026-05-20 | IDOX SOFTWARE LTD | £2,647.21 | Development & Housing |
| 8 | `Over500_2026_P03_-_published.xlsx:2130` | 2026-06-09 | TWO SAINTS LTD | £38,775.00 | Development & Housing |
| 8 | `Over500_2026_P04_-_published.xlsx:3181` | 2026-07-22 | TWO SAINTS LTD | £38,775.00 | Development & Housing |


## Prepared-by-client (PBC) request list

Derived from the test steps above. Each item names the tests that need it.

| # | Risk | Item requested | For tests |
|---|---|---|---|
| 1 | R-01 | Purchase orders, quotations and requirement records for sampled windows | T-01.1 |
| 2 | R-01 | Contract route decision records and VAT basis for sampled suppliers | T-01.1 |
| 3 | R-02 | Council contract register extract | T-02.1 |
| 4 | R-02 | Formal award notification evidence for sampled suppliers | T-02.1 |
| 5 | R-02 | Supporting published notice references for sampled suppliers | T-02.1 |
| 6 | R-03 | Invoices and purchase orders for sampled groups | T-03.1 |
| 7 | R-03 | Goods receipt or service confirmation for sampled groups | T-03.1 |
| 8 | R-03 | Invoice validity and settlement dates for sampled groups | T-03.1 |
| 9 | R-04 | Case notes for sampled placements | T-04.1 |
| 10 | R-04 | Exemption and approval records for sampled placements | T-04.1 |
| 11 | R-05 | Extension or variation instruments for sampled suppliers | T-05.1 |
| 12 | R-05 | Approval records for sampled extensions | T-05.1 |
| 13 | R-05 | Variation approvals for sampled suppliers | T-05.2 |
| 14 | R-05 | Award records with term and value for sampled suppliers | T-05.2 |
